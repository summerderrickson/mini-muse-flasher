# Flashing Mini Muse onto the reTerminal Sticky

This guide covers both of your Stickies. The steps are identical, just give
each one its own device name at the end (`sticky-home` and `sticky-car`).

## What you need

- A computer with **Chrome** or **Edge**
- A **USB-C data cable** (important: some cables only carry power and will not
  show a serial port; if nothing appears, swap the cable first)
- The `flasher` folder from this project, containing:
  - `index.html` (this web flasher page)
  - `manifest.json`
  - `mini-muse.bin`, `bootloader.bin`, `partitions.bin`, `boot_app0.bin`

## Method 1: Web flasher (easiest)

1. Open a terminal **in the `flasher` folder** and run:
   ```
   python3 -m http.server 8000
   ```
   (Web browsers can only talk to USB from a real web address, not from a
   file you double click. `http://localhost:8000` counts.)
2. In Chrome or Edge, open **http://localhost:8000**.
3. Plug the Sticky into your computer with the USB-C cable.
4. Click **Connect and flash Mini Muse**, then pick the Sticky's serial port
   from the list (it looks like `USB Serial` / `cu.usbmodem...` / `COM3`).
5. Press **Install** and confirm the erase prompt. Flashing takes a couple of
   minutes. Do not unplug while it runs.
6. When it says done, the Sticky restarts into Mini Muse.

If the port does not appear: try another cable, another USB port, and close
any other program that might hold the port (Arduino IDE, serial monitors).

## Method 2: Command line with esptool.py

Install it once with `pip install esptool`, then from the `flasher` folder:

```
esptool.py --chip esp32s3 --port /dev/ttyACM0 --baud 921600 \
  --before default_reset --after hard_reset write_flash \
  --flash_mode dio --flash_freq 80m --flash_size 32MB \
  0x0 bootloader.bin \
  0x8000 partitions.bin \
  0xe000 boot_app0.bin \
  0x10000 mini-muse.bin
```

On macOS the port is usually `/dev/cu.usbmodem...`, on Windows `COM3` or similar.
To wipe the device completely first (fresh start), add `erase_flash` before
`write_flash`.

## First boot setup (do this on each Sticky)

1. The Sticky boots to the Mini Muse home screen.
2. **Hold UP + DOWN together** until the WiFi setup portal opens. A network
   called `MiniMuse-XXXX` appears.
3. On your phone, join the `MiniMuse-XXXX` network. A setup page opens.
4. Enter:
   - Your **WiFi name and password**
   - Your **Groq API key** (free at groq.com, used to transcribe your voice)
   - A **device name**: `sticky-home` for one unit, `sticky-car` for the other.
     The name is how Muse's replies find the right Sticky.
5. Save. The Sticky connects, syncs its clock over the internet, and is ready.

No passwords or keys are ever stored anywhere except on the Sticky itself.

## After setup

- **Ask Muse**: hold the AI button and talk. Offline recordings queue up and
  send automatically when WiFi returns.
- **Photos / Wallet / Books**: put a microSD card in (FAT32) with `/photos/`,
  `/wallet/`, and `/books/` folders, or use the built-in storage fallback.
  Convert images with `python3 tools/photo_convert.py pic.jpg -o pic.bmp`
  (add `--qr` for Wallet QR codes).
- **Customize**: Settings has a "Home apps" screen to show or hide apps on
  the home grid.

## Troubleshooting

- **Nothing on screen after flashing**: unplug, wait 5 seconds, plug back in.
- **Stuck on the home screen with no data**: the cached screens fill in the
  first time each app syncs over WiFi. Open Tasks or Calendar once while
  connected.
- **Voice answers never arrive**: make sure the bridge cron on the agent side
  is running, and that the device name matches the one Muse expects.
- **"Failed to connect" in the web flasher**: cable, port, then browser. In
  that order, it is the cable 90 percent of the time.
